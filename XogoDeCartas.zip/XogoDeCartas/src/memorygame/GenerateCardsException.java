/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package memorygame;

/**
 *
 * @author roi.castrocalvar
 */
public class GenerateCardsException extends Exception {
    public GenerateCardsException(String message) {
        super(message);
    }
}
