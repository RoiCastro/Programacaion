/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alphabetsoup;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author roi.castrocalvar
 */
public class AlphabetSoupApp {

    // Lista coas sopas de letras dispoñibles na app
    private ArrayList<AlphabetSoup> soupList = new ArrayList<>();
    
    /**
     * Devolve a lista de sopas de letras dispoñibles
     *
     * @return Lista con todas as sopas de letras
     */
    public ArrayList<AlphabetSoup> getSoupList() {
        return soupList;
    }

    /**
     * Establece a lista de sopas de letras dispoñibles
     *
     * @param soupList Lista coas sopas de letras
     */
    public void setSoupList(ArrayList<AlphabetSoup> soupList) {
        this.soupList = soupList;
    }

    /**
     * Crea un novo obxecto para executar a aplicación de sopas de letras
     */
    public AlphabetSoupApp() {
        // Cargamos a sopa de letras por defecto
        addDefaultSoup();
    }

    /**
     * Mostra a lista con todas as sopas de letras e pide ao usuario que
     * selecciona unha delas
     *
     * @return Sopa de letras seleccionada polo usuario
     */
    public AlphabetSoup selectSoup() {
        Scanner scan = new Scanner(System.in);

        // Mostramos as sopas de letras dispoñibles
        System.out.println("Sopas de letras dispoñibles:");
        for (int i = 0; i < soupList.size(); i++) {
            System.out.println((i + 1) + ". " + soupList.get(i).getTitle());
        }

        // Pedimos ao usuario o número dunha sopa da lista e devolvémola
        System.out.println("Introduce o número dunha sopa de letras:");
        return soupList.get(scan.nextInt() - 1);
    }

    /**
     * Método que mostra o menú da aplicación e devolve a opción introducida
     * polo usuario
     *
     * @return Opción seleccionada do menú
     */
    public int showMainMenu() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Benvido á App de sopas de letras!");
        System.out.println();
        System.out.println("1. Engadir unha nova sopa de letras");
        System.out.println("2. Resolver unha sopa de letras");
        System.out.println("3. Saír");
        System.out.println("Introduce una opción:");
        return (scan.nextInt());
    }

    /**
     * Engade unha sopa de letras por defecto
     */
    private void addDefaultSoup() {
        char[][] soup = {
            {'J', 'A', 'V', 'A', 'M'},
            {'O', 'A', 'G', 'H', 'A'},
            {'T', 'U', 'C', 'G', 'I'},
            {'T', 'N', 'I', 'K', 'N'}};
        String[] words = {"JAVA", "MAIN", "JACK", "INT"};
        soupList.add(new AlphabetSoup("Sobre Java", soup, words));
    }

    /**
     * Inicia a execución da aplicación
     *
     * @param args Argumentos en liña de comandos
     */
    public static void main(String[] args) {
        int option;

        // Creamos un obxecto para a aplicación
        AlphabetSoupApp myApp = new AlphabetSoupApp();
        
        // Mostramos o menú mentres a opción seleccionada non sexa a de saír
        do {
            option = myApp.showMainMenu();
            switch (option) {
                case 1:
                    
                    break;
                case 2:
                    // Pedimos ao usuario que seleccions unha sopa de letras e
                    // mostrámola
                    AlphabetSoup soup = myApp.selectSoup();
                    soup.display();
                    break;
                case 3:
                    System.out.println("Ata logo!");
                    break;
                default:
                    System.out.println("Opción incorrecta! "
                            + "Introduce unha opción entre 1 e 3");
            }
        } while (option != 3);
    }
    
}