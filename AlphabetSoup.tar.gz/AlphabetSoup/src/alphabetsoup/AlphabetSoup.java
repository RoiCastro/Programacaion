/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package alphabetsoup;

import java.util.Scanner;

/**
 *
 * @author roi.castrocalvar
 */
public class AlphabetSoup {

    private String title;
    private char[][] soup;
    private String[] words;
    private final static int BIGER_NUMBER = 8;

    /**
     * Obtén o título da sopa de letras
     *
     * @return Título da sopa de letras
     */
    public String getTitle() {
        return title;
    }

    /**
     * Establece o título da sopa de letras
     *
     * @param title Novo título
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Obtén a táboa cos caracteres da sopa de letras
     *
     * @return Array bidimensional cos caracteres
     */
    public char[][] getSoup() {
        return soup;
    }

    /**
     * Establece a táboa cos caracteres da sopa de letras
     *
     * @param soup Array bidimensional cos caracteres
     */
    public void setSoup(char[][] soup) {
        this.soup = soup;
    }

    /**
     * Obtén as palabras agochadas na sopa de letras
     *
     * @return Array coas palabras agochadas
     */
    public String[] getWords() {
        return words;
    }

    /**
     * Estabelce a lista de palabras agochadas na sopa de letras
     *
     * @param words Array coas palabras agochadas
     */
    public void setWords(String[] words) {
        this.words = words;
    }

    /**
     * Crea unha nova sopa de letras
     *
     * @param title Título da sopa de letras
     * @param soup Táboa de caracteres da sopa de letras
     * @param words Lista de palabras agochadas na sopa de letras
     */
    public AlphabetSoup(String title, char[][] soup, String[] words) {
        this.title = title;
        this.soup = soup;
        this.words = words;
    }

    /**
     * Mostra o título e as letras da sopa por pantalla
     */
    public void display() {
        System.out.println("Sopa de letras: " + title);
        for (char[] row : soup) {
            for (char letter : row) {
                System.out.print(letter + " ");
            }
            System.out.println();
        }
    }

    public void addSoup() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Escribe el titulo para");
        String title = scan.nextLine();

        System.out.println("Para la sopa de letras.");
        int rows;
        do {
            System.out.println("Dime el numero de filas :");
            rows = scan.nextInt();
            if (rows < BIGER_NUMBER) {
                System.out.println("Para este tamaño debes usar a versión PRO!");
            }
        } while (rows > BIGER_NUMBER);
        scan.nextLine();
        System.out.println("Dime el numero de columnas :");
        int colums;
        do {
            System.out.println("Dime el numero de columnas :");
            colums = scan.nextInt();
            if (colums < BIGER_NUMBER) {
                System.out.println("Para este tamaño debes usar a versión PRO!");
            }
        } while (colums > BIGER_NUMBER);
        scan.nextLine();
        System.out.println("Rellenamos la sopa");
        Scanner scanner = new Scanner(System.in);
        char[][] soup = new char[rows][colums];
        for (int i = 0; i < colums; i++) {
            for (int j = 0; j < rows; j++) {
                System.out.println();
                System.out.println("Escribe la fila " + i + " columna " + j);
                soup[i][j] = scanner.nextLine().charAt(0);
                scanner.nextLine();
                System.out.println();
            }

        }

        System.out.println("Cuantas palabras contine");
        int number = scan.nextInt();
        scanner.nextLine();

        System.out.println("Escribe las palabras qeu contine");
        String[] words = new String[number];
        for (int i = 0; i < number; i++) {
            words[i] = scan.nextLine();
        }

        new AlphabetSoup(title, soup, words);
    }
}
